This library is the same then the lib from Yann Jautard

I just add the 3D wrl file and the value for scaling 

You need to use the arduino.mod here to have the good offset and scaling

Scale : 
X = 0.393700 
Y = 0.393700 
Z = 0.393700

Offset :
X = -0.978000 
Y = -0.385000 
Z = 0.000000

Rotation 
0.000000 
0.000000 
0.000000
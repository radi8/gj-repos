Librairies for MS 5535C pressure sensor from intermesa 

Digital sensor, temp compensated
0 to 14 bar
3 wires interface 